<footer class="admin-footer">
    <p>© 2025 Hotel Management System</p>
</footer>
<?php /**PATH C:\laragon\www\du_an_tot_nghiep\du_an_tot_nghiep\du_an_tot_nghiep\resources\views/partials/admin-footer.blade.php ENDPATH**/ ?>