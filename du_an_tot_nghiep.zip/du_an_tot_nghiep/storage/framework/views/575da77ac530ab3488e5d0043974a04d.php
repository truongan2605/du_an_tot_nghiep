<?php $__env->startSection('title', 'Đăng nhập'); ?>

<?php $__env->startSection('content'); ?>
    <section class="vh-xxl-100">
        <div class="container h-100 d-flex px-0 px-sm-4">
            <div class="row justify-content-center align-items-center m-auto">
                <div class="col-12">
                    <div class="bg-mode shadow rounded-3 overflow-hidden">
                        <div class="row g-0">
                            <!-- Vector Image -->
                            <div class="col-lg-6 d-flex align-items-center order-2 order-lg-1">
                                <div class="p-3 p-lg-5">
                                    <img src="<?php echo e(asset('template/stackbros/assets/images/element/signin.svg')); ?>"
                                        alt="">
                                </div>
                                <div class="vr opacity-1 d-none d-lg-block"></div>
                            </div>

                            <!-- Information -->
                            <div class="col-lg-6 order-1">
                                <div class="p-4 p-sm-7">
                                    <a href="<?php echo e(url('/')); ?>">
                                        <img class="h-50px mb-4"
                                            src="<?php echo e(asset('template/stackbros/assets/images/logo-icon.svg')); ?>"
                                            alt="logo">
                                    </a>
                                    <h1 class="mb-2 h3">Chào mừng trở lại</h1>
                                    <p class="mb-0">Chưa có tài khoản? <a href="<?php echo e(route('register')); ?>">Tạo tài khoản</a></p>

                                    <!-- Form START -->
                                    <form class="mt-4 text-start" method="POST" action="<?php echo e(route('login')); ?>">
                                        <?php echo csrf_field(); ?>

                                        <!-- Hiển thị lỗi từ session (khi logout từ toggle) -->
                                        <?php if(session('error')): ?>
                                            <div class="alert alert-danger mb-3">
                                                <?php echo e(session('error')); ?>

                                            </div>
                                        <?php endif; ?>

                                        <!-- Email -->
                                        <div class="mb-3">
                                            <label class="form-label">Nhập email</label>
                                            <input type="email" name="email" value="<?php echo e(old('email')); ?>"
                                                class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required
                                                autofocus>
                                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <!-- Password -->
                                        <div class="mb-3 position-relative">
                                            <label class="form-label">Nhập mật khẩu</label>
                                            <input name="password" class="form-control fakepassword" type="password"
                                                id="psw-input" required>
                                            <span class="position-absolute top-50 end-0 translate-middle-y p-0 mt-3">
                                                <i class="fakepasswordicon fas fa-eye-slash cursor-pointer p-2"></i>
                                            </span>
                                        </div>

                                        <!-- Remember me -->
                                        <div class="mb-3 d-sm-flex justify-content-between">
                                            <div>
                                                <input type="checkbox" name="remember" class="form-check-input"
                                                    id="rememberCheck" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                                                <label class="form-check-label" for="rememberCheck">Ghi nhớ đăng nhập?</label>
                                            </div>
                                            <a href="<?php echo e(route('password.request')); ?>">Quên mật khẩu?</a>
                                        </div>

                                        <!-- Button -->
                                        <div><button type="submit" class="btn btn-primary w-100 mb-0">Đăng nhập</button></div>

                                        <div class="position-relative my-4">
                                            <hr>
                                            <p
                                                class="small bg-mode position-absolute top-50 start-50 translate-middle px-2">
                                                Hoặc đăng nhập bằng</p>
                                        </div>

                                        <!-- Google and facebook button -->
                                        <div class="vstack gap-3" >
                                            <a href="<?php echo e(route('auth.google')); ?>" class="btn btn-light mb-0">
                                                <i class="fab fa-fw fa-google text-google-icon me-2"></i>Đăng nhập bằng Google
                                            </a>
                                        </div>
                                    </form>
                                    <!-- Form END -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\du_an_tot_nghiep\du_an_tot_nghiep\du_an_tot_nghiep\resources\views/auth/login.blade.php ENDPATH**/ ?>