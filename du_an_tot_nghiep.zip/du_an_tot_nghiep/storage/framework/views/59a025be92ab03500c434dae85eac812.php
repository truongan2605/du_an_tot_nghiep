<?php $__env->startSection('title', 'Chi tiết phòng'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <?php if(session('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul class="mb-0">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($err); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <div class="card shadow-lg border-0 rounded-3">
            <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                <h4 class="mb-0">Chi tiết phòng: <?php echo e($phong->ma_phong); ?></h4>
                <a href="<?php echo e(route('admin.phong.index')); ?>" class="btn btn-light btn-sm">← Quay lại</a>
            </div>

            <div class="card-body">
                <div class="row">
                    <!-- Thông tin chính -->
                    <div class="col-md-6">
                        <h5 class="fw-bold">Thông tin chung</h5>
                        <table class="table table-bordered align-middle">
                            <tr>
                                <th>Mã phòng</th>
                                <td><?php echo e($phong->ma_phong); ?></td>
                            </tr>
                            <tr>
                                <th>Tên phòng</th>
                                <td><?php echo e($phong->name ?? '-'); ?></td>
                            </tr>
                            <tr>
                                <th>Mô tả</th>
                                <td><?php echo nl2br(e($phong->mo_ta ?? '-')); ?></td>
                            </tr>

                            <tr>
                                <th>Loại phòng</th>
                                <td>
                                    <?php echo e($phong->loaiPhong?->ten ?? '-'); ?>

                                    <?php if($phong->loaiPhong): ?>
                                        <div class="small text-muted">Giá loại:
                                            <strong><?php echo e(number_format($phong->loaiPhong->gia_mac_dinh ?? 0, 0, ',', '.')); ?>

                                                đ</strong>
                                        </div>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <tr>
                                <th>Tầng</th>
                                <td><?php echo e($phong->tang?->ten); ?></td>
                            </tr>
                            <tr>
                                <th>Sức chứa</th>
                                <td><?php echo e($phong->suc_chua); ?> người</td>
                            </tr>
                            <tr>
                                <th>Số giường</th>
                                <td><?php echo e($phong->so_giuong); ?></td>
                            </tr>
                            <tr>
                                <th>Giá mặc định (phòng)</th>
                                <td><?php echo e(number_format($phong->gia_mac_dinh, 0, ',', '.')); ?> VNĐ</td>
                            </tr>
                            <tr>
                                <th>Trạng thái</th>
                                <td>
                                    <?php
                                        $map = [
                                            'khong_su_dung' => ['label' => 'Không sử dụng', 'class' => 'secondary'],
                                            'trong' => ['label' => 'Trống', 'class' => 'success'],
                                            'dang_o' => ['label' => 'Đang ở', 'class' => 'primary'],
                                            'bao_tri' => ['label' => 'Bảo trì', 'class' => 'warning'],
                                        ];
                                        $st = $map[$phong->trang_thai] ?? [
                                            'label' => $phong->trang_thai,
                                            'class' => 'secondary',
                                        ];
                                    ?>
                                    <span class="badge bg-<?php echo e($st['class']); ?>"><?php echo e($st['label']); ?></span>
                                </td>
                            </tr>

                        </table>

                        <?php
                            $typePrice = (float) ($phong->loaiPhong->gia_mac_dinh ?? 0);
                            $typeAmenities = $phong->loaiPhong?->tienNghis ?? collect();
                            $roomAmenitiesAll = $phong->tienNghis ?? collect();

                            $typeAmenitiesSum = $typeAmenities->sum('gia');

                            $boSung = $roomAmenitiesAll->reject(function ($item) use ($typeAmenities) {
                                return $typeAmenities->contains('id', $item->id);
                            });
                            $boSungSum = $boSung->sum('gia');

                            $allIds = array_values(
                                array_unique(
                                    array_merge(
                                        $typeAmenities->pluck('id')->toArray(),
                                        $roomAmenitiesAll->pluck('id')->toArray(),
                                    ),
                                ),
                            );
                            $allAmenitiesSum = \App\Models\TienNghi::whereIn('id', $allIds)->sum('gia');

                            $bedTotal = 0;
                            if ($phong->relationLoaded('bedTypes') || $phong->bedTypes()->exists()) {
                                $bts = $phong->bedTypes()->get();
                                foreach ($bts as $bt) {
                                    $qty = (int) ($bt->pivot->quantity ?? 0);
                                    $pricePer =
                                        $bt->pivot->price !== null
                                            ? (float) $bt->pivot->price
                                            : (float) ($bt->price ?? 0);
                                    $bedTotal += $qty * $pricePer;
                                }
                            }

                            $totalDisplay = $phong->tong_gia;
                        ?>


                        <div class="mt-3">
                            <h5 class="fw-bold">Cấu hình giường</h5>
                            <?php if($phong->bedTypes->count()): ?>
                                <table class="table table-sm">
                                    <thead>
                                        <tr>
                                            <th>Loại giường</th>
                                            <th class="text-center">Số lượng</th>
                                            <th class="text-center">Sức chứa/giường</th>
                                            <th class="text-end">Giá/giường</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $phong->bedTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($bt->name); ?></td>
                                                <td class="text-center"><?php echo e($bt->pivot->quantity ?? 0); ?></td>
                                                <td class="text-center"><?php echo e($bt->capacity); ?></td>
                                                <td class="text-end">
                                                    <?php echo e(number_format($bt->pivot->price ?? ($bt->price ?? 0), 0, ',', '.')); ?>

                                                    đ
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            <?php else: ?>
                                <p><em>Không có cấu hình giường</em></p>
                            <?php endif; ?>
                        </div>


                        <div class="card mt-3">
                            <div class="card-header">Phân tích giá</div>
                            <div class="card-body p-2">
                                <table class="table table-sm mb-0">
                                    <tr>
                                        <td>Giá loại phòng</td>
                                        <td class="text-end"><strong><?php echo e(number_format($typePrice, 0, ',', '.')); ?>

                                                đ</strong></td>
                                    </tr>
                                    <tr>
                                        <td>Tổng tiện nghi mặc định</td>
                                        <td class="text-end"><?php echo e(number_format($typeAmenitiesSum, 0, ',', '.')); ?> đ</td>
                                    </tr>
                                    <tr class="table-active">
                                        <td>Tổng giá giường</td>
                                        <td class="text-end"><?php echo e(number_format($bedTotal, 0, ',', '.')); ?> đ</td>
                                    </tr>

                                    <tr>
                                        <th>Tổng giá phòng (hiện tại)</th>
                                        <th class="text-end text-success"><?php echo e(number_format($totalDisplay, 0, ',', '.')); ?> đ
                                        </th>
                                    </tr>
                                </table>
                            </div>
                        </div>

                    </div>

                    <!-- Ảnh -->
                    <div class="col-md-6">
                        <h5 class="fw-bold">Hình ảnh</h5>
                        <?php if($phong->images->count()): ?>
                            <div class="row g-2">
                                <?php $__currentLoopData = $phong->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-6 col-md-4">
                                        <div class="border rounded shadow-sm">
                                            <img src="<?php echo e(asset('storage/' . $img->image_path)); ?>" class="img-fluid rounded"
                                                style="object-fit: contain; max-height: 180px; width: 100%;">
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php else: ?>
                            <p><em>Chưa có ảnh</em></p>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Tiện nghi -->
                <div class="mt-4">
                    <h5 class="fw-bold">Tiện nghi</h5>

                    <div class="row">
                        <div class="col-12">
                            <div class="card border-success">
                                <div class="card-header bg-success text-white">Tiện nghi</div>
                                <div class="card-body">
                                    <?php if($tienNghiLoaiPhong->count()): ?>
                                        <ul class="list-unstyled mb-0">
                                            <?php $__currentLoopData = $tienNghiLoaiPhong; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li>
                                                    ✔ <?php echo e($tn->ten); ?>

                                                    <small class="text-muted"> —
                                                        <?php echo e(number_format($tn->gia ?? 0, 0, ',', '.')); ?> đ</small>
                                                </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    <?php else: ?>
                                        <p><em>Không có tiện nghi mặc định</em></p>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Vật dụng -->
                <div class="mt-4">
                    <h5 class="fw-bold">Vật dụng</h5>
                    <div class="row gy-3">
                        <!-- Đồ vật (do_dung) — danh sách theo loại phòng -->
                        <div class="col-md-6">
                            <div class="card border-dark">
                                <div
                                    class="card-header bg-dark text-white d-flex justify-content-between align-items-center">
                                    <div>Đồ vật</div>
                                    <a href="<?php echo e(route('admin.phong.vatdung.instances.index', ['phong' => $phong->id])); ?>"
                                        class="btn btn-sm btn-light">Quản lý chi tiết</a>
                                </div>
                                <div class="card-body">
                                    <?php if($vatDungLoaiPhongDoDung->count()): ?>
                                        <ul class="list-unstyled mb-0">
                                            <?php $__currentLoopData = $vatDungLoaiPhongDoDung; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php
                                                    $inst = $instancesMap[$vd->id] ?? null;
                                                    $instCount = $inst['count'] ?? 0;
                                                    $activeBooking = $activeDatPhong ?? null;
                                                    $canOperate =
                                                        $activeBooking &&
                                                        in_array($activeBooking->trang_thai, [
                                                            'da_dat',
                                                            'dang_su_dung',
                                                            'da_xac_nhan',
                                                            'dang_cho_xac_nhan',
                                                        ]);
                                                ?>

                                                <li class="mb-2">
                                                    ✔ <?php echo e($vd->ten); ?>

                                                    <small class="text-muted"> —
                                                        <?php echo e(number_format($vd->gia ?? 0, 0, ',', '.')); ?> đ</small>
                                                    <?php if($instCount > 0): ?>
                                                        <span class="badge bg-info ms-2">Số lượng:
                                                            <?php echo e($instCount); ?></span>
                                                    <?php else: ?>
                                                        <span class="text-muted ms-2">Không có bản thể</span>
                                                    <?php endif; ?>


                                                </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    <?php else: ?>
                                        <p><em>Không có đồ vật mặc định cho loại phòng này.</em></p>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>

                        <!-- Đồ ăn (do_an) trong phòng + số lượng hiện tại -->
                        

                    </div>
                </div>

                <div class="mt-3 text-end">
                    <h5>Tổng giá phòng:
                        <span class="text-success fw-bold">
                            <?php echo e(number_format($phong->tong_gia, 0, ',', '.')); ?> VNĐ
                        </span>
                    </h5>
                </div>
            </div> <!-- card-body -->
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            document.querySelectorAll('.consume-form').forEach(function(form) {
                form.addEventListener('submit', function(e) {
                    const qtyInput = form.querySelector('.qty-to-consume');
                    if (!qtyInput || qtyInput.disabled) {
                        e.preventDefault();
                        alert('Không có hàng để tiêu thụ.');
                        return;
                    }
                    const val = parseInt(qtyInput.value || '0', 10);
                    const maxv = parseInt(qtyInput.getAttribute('max') || '0', 10);
                    if (isNaN(val) || val <= 0) {
                        e.preventDefault();
                        alert('Vui lòng nhập số lượng lớn hơn 0.');
                        return;
                    }
                    if (val > maxv) {
                        e.preventDefault();
                        alert('Số lượng vượt quá phần còn lại (' + maxv + ').');
                        return;
                    }
                    // allow submit
                });
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\du_an_tot_nghiep\du_an_tot_nghiep\du_an_tot_nghiep\resources\views/admin/phong/show.blade.php ENDPATH**/ ?>