<?php $__env->startSection('title', 'Danh sách phòng'); ?>

<?php $__env->startSection('content'); ?>
    <!-- =======================
                    Banner START -->
    <section class="position-relative overflow-hidden rounded-4 mt-4 mx-auto"
        style="height: 360px; width: 90%; max-width: 1200px;">
        <!-- Background Image -->
        <img src="<?php echo e(asset('template/stackbros/assets/images/bg/07.jpg')); ?>" alt="banner"
            class="position-absolute top-0 start-0 w-100 h-100 object-fit-cover rounded-4"
            style="filter: brightness(70%); object-position: center;">

        <!-- Overlay -->
        <div class="position-absolute top-0 start-0 w-100 h-100 rounded-4" style="background: rgba(0, 0, 0, 0.4);"></div>

        <!-- Text -->
        <div
            class="position-relative z-2 text-center text-white d-flex flex-column justify-content-center align-items-center h-100">
            <h1 class="display-5 fw-bold mb-3" style="color: #ddd">Danh sách phòng khả dụng</h1>
            <p class="lead mb-0" style="max-width: 600px;">
                Khám phá các phòng đang hoạt động trong hệ thống của chúng tôi
            </p>
        </div>
    </section>
    <!-- =======================
                    Banner END -->

    <section class="pt-4 pb-5">
        <div class="container">
            <div class="row g-4">
                
                <aside class="col-lg-3">
                    <form method="GET" action="<?php echo e(route('list-room.index')); ?>" class="card border-0 shadow-sm">
                        <div class="filter-box sidebar-filter">
                            
                            <h6 class="fw-bold mb-3">Loại phòng</h6>
                            <ul class="list-unstyled">
                                <li>
                                    <input type="radio" name="loai_phong_id" id="type_all" value=""
                                        <?php echo e(request('loai_phong_id') == '' ? 'checked' : ''); ?>>
                                    <label for="type_all">Tất cả loại phòng</label>
                                </li>

                                <?php $__currentLoopData = $loaiPhongs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <input type="radio" name="loai_phong_id" id="type_<?php echo e($loai->id); ?>"
                                            value="<?php echo e($loai->id); ?>"
                                            <?php echo e(request('loai_phong_id') == $loai->id ? 'checked' : ''); ?>>
                                        <label for="type_<?php echo e($loai->id); ?>"><?php echo e($loai->ten); ?></label>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>

                            
                            <h6>Nhận phòng - Trả phòng</h6>
                            <input type="text" class="form-control flatpickr mb-3" data-mode="range"
                                placeholder="Chọn ngày" name="date_range" value="<?php echo e(request('date_range')); ?>">

                            <h6>Giá (VNĐ)</h6>
                            <div class="mb-3">
                                <div id="price-slider"></div>
                                <div class="d-flex justify-content-between mt-2">
                                    <span id="min-price"
                                        class="small fw-semibold"><?php echo e(number_format($giaMin, 0, ',', '.')); ?>đ</span>
                                    <span id="max-price"
                                        class="small fw-semibold"><?php echo e(number_format($giaMax, 0, ',', '.')); ?>đ</span>
                                </div>
                                <input type="hidden" id="gia_min" name="gia_min"
                                    value="<?php echo e(request('gia_min', $giaMin)); ?>">
                                <input type="hidden" id="gia_max" name="gia_max"
                                    value="<?php echo e(request('gia_max', $giaMax)); ?>">
                            </div>

                            <div class="filter-divider"></div>

                            
                            <h6 class="fw-bold mb-3">Đánh giá sao</h6>
                            <ul class="list-unstyled mb-3">
                                <?php for($i = 5; $i >= 1; $i--): ?>
                                    <li class="mb-1">
                                        <input type="radio" name="diem" id="star<?php echo e($i); ?>"
                                            value="<?php echo e($i); ?>" <?php echo e(request('diem') == $i ? 'checked' : ''); ?>>
                                        <label for="star<?php echo e($i); ?>">
                                            <?php for($j = 1; $j <= $i; $j++): ?>
                                                <i class="bi bi-star-fill text-warning"></i>
                                            <?php endfor; ?>
                                            <?php for($j = $i + 1; $j <= 5; $j++): ?>
                                                <i class="bi bi-star text-muted"></i>
                                            <?php endfor; ?>
                                        </label>
                                    </li>
                                <?php endfor; ?>
                                <li>
                                    <input type="radio" name="diem" id="all_rating" value=""
                                        <?php echo e(request('diem') == '' ? 'checked' : ''); ?>>
                                    <label for="all_rating">Tất cả đánh giá</label>
                                </li>
                            </ul>

                            
                            <h6>Dịch vụ</h6>
                            <ul class="list-unstyled">
                                <?php
                                    $selectedTienNghi = (array) request('tien_nghi', []);
                                ?>

                                <?php $__currentLoopData = $tienNghis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tienNghi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <input type="checkbox" name="tien_nghi[]" id="amenity<?php echo e($tienNghi->id); ?>"
                                            value="<?php echo e($tienNghi->id); ?>"
                                            <?php echo e(in_array($tienNghi->id, $selectedTienNghi) ? 'checked' : ''); ?>>
                                        <label for="amenity<?php echo e($tienNghi->id); ?>"><?php echo e($tienNghi->ten); ?></label>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>

                            <div class="mt-3">
                                <button type="submit" class="filter-submit-btn">Tìm kiếm</button>
                            </div>
                        </div>

                    </form>
                </aside>

                
                <div class="col-lg-9">
                    <div class="row g-4">
                        <?php $__empty_1 = true; $__currentLoopData = $phongs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $phong): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <?php
                                $loaiPhong = $phong->loaiPhong;
                            ?>

                            <div class="col-12">
                                <div
                                    class="card border-0 shadow-sm rounded-4 overflow-hidden mb-4 room-card position-relative hover-shadow transition-all">

                                    
                                    <div class="row g-0 align-items-center">
                                        <div class="col-md-5 position-relative">

                                            <?php if($phong->images->count() > 1): ?>
                                                <div id="carouselRoom<?php echo e($phong->id); ?>" class="carousel slide"
                                                    data-bs-ride="carousel" data-bs-interval="3000">
                                                    <div class="carousel-inner room-carousel-inner rounded-start">
                                                        <?php $__currentLoopData = $phong->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <div class="carousel-item <?php echo e($key == 0 ? 'active' : ''); ?>">
                                                                <img src="<?php echo e(asset('storage/' . $img->image_path)); ?>"
                                                                    class="d-block w-100 h-100 object-fit-cover rounded-start-4"
                                                                    alt="Image <?php echo e($key + 1); ?>">
                                                            </div>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>
                                                    <button class="carousel-control-prev" type="button"
                                                        data-bs-target="#carouselRoom<?php echo e($phong->id); ?>"
                                                        data-bs-slide="prev">
                                                        <span
                                                            class="carousel-control-prev-icon bg-dark rounded-circle p-2"></span>
                                                    </button>
                                                    <button class="carousel-control-next" type="button"
                                                        data-bs-target="#carouselRoom<?php echo e($phong->id); ?>"
                                                        data-bs-slide="next">
                                                        <span
                                                            class="carousel-control-next-icon bg-dark rounded-circle p-2"></span>
                                                    </button>
                                                </div>
                                            <?php else: ?>
                                                <img src="<?php echo e(asset('storage/' . ($phong->images->first()->image_path ?? 'template/stackbros/assets/images/default-room.jpg'))); ?>"
                                                    class="w-100 h-100 object-fit-cover rounded-start-4"
                                                    alt="<?php echo e($phong->name); ?>">
                                            <?php endif; ?>

                                            
                                            <?php if(isset($phong->khuyen_mai) && $phong->khuyen_mai > 0): ?>
                                                <span
                                                    class="badge bg-danger position-absolute top-0 start-0 m-3 px-3 py-2 fs-6 shadow-sm">
                                                    -<?php echo e($phong->khuyen_mai); ?>%
                                                </span>
                                            <?php endif; ?>
                                        </div>

                                        
                                        <div class="col-md-7">
                                            <div class="card-body py-4 px-4">
                                                
                                                <div class="d-flex align-items-center mb-2">
                                                    <?php for($i = 1; $i <= 5; $i++): ?>
                                                        <i
                                                            class="bi bi-star<?php echo e($i <= ($phong->so_sao ?? 4) ? '-fill text-warning' : ''); ?> me-1"></i>
                                                    <?php endfor; ?>
                                                </div>

                                                
                                                <h5 class="fw-bold mb-1">
                                                    <?php echo e($loaiPhong->ten ?? ($phong->name ?? $phong->ma_phong)); ?>

                                                </h5>

                                                
                                                <p class="text-muted mb-2">
                                                    <i class="bi bi-geo-alt me-1"></i>
                                                    <?php echo e($phong->mo_ta ?? 'Mô tả đang cập nhật'); ?>

                                                </p>
                                                
                                                <p class="text-muted mb-2">
                                                    <?php if(request('date_range') && !is_null($phong->so_phong_trong)): ?>
                                                        Còn <?php echo e($phong->so_phong_trong); ?> /
                                                        <?php echo e($phong->so_luong_phong_cung_loai ?? 0); ?> phòng trống cho ngày đã
                                                        chọn
                                                    <?php else: ?>
                                                        Có <?php echo e($phong->so_luong_phong_cung_loai ?? 0); ?> phòng trong hệ thống
                                                    <?php endif; ?>
                                                </p>
                                                
                                                <div class="small text-muted mb-2">
                                                    <?php if($phong->tienNghis && $phong->tienNghis->count()): ?>
                                                        <?php $__currentLoopData = $phong->tienNghis->take(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tiennghi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <span class="me-2">
                                                                <i class="bi bi-check-circle text-success me-1"></i>
                                                                <?php echo e($tiennghi->ten); ?>

                                                            </span>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                        <?php if($phong->tienNghis->count() > 3): ?>
                                                            <a href="<?php echo e(route('rooms.show', $phong->id)); ?>"
                                                                class="text-decoration-none">Xem thêm+</a>
                                                        <?php endif; ?>
                                                    <?php else: ?>
                                                        <span>Chưa có dịch vụ</span>
                                                    <?php endif; ?>
                                                </div>

                                                
                                                <div class="d-flex justify-content-between align-items-center">
                                                    <div>
                                                        <h4 class="fw-bold text-primary mb-0">
                                                            <?php echo e(number_format($phong->gia_cuoi_cung, 0, ',', '.')); ?> VNĐ
                                                            <span class="small fw-normal text-muted">/Đêm</span>
                                                        </h4>
                                                    </div>

                                                    <div class="d-flex gap-2">
                                                        
                                                        <button type="button" 
                                                                class="btn btn-outline-primary rounded-pill px-3 py-2 compare-btn"
                                                                data-room-id="<?php echo e($phong->id); ?>"
                                                                data-room-name="<?php echo e($loaiPhong->ten ?? $phong->name); ?>"
                                                                data-room-price="<?php echo e($phong->gia_cuoi_cung); ?>"
                                                                data-room-image="<?php echo e(asset('storage/' . ($phong->images->first()->image_path ?? 'template/stackbros/assets/images/default-room.jpg'))); ?>"
                                                                title="So sánh phòng">
                                                            <i class="bi bi-plus-circle me-1"></i>
                                                            <span class="compare-text">So sánh</span>
                                                        </button>
                                                        
                                                        
                                                        <a href="<?php echo e(route('rooms.show', $phong->id)); ?>"
                                                            class="btn btn-dark rounded-pill px-4 py-2">
                                                            Chọn phòng
                                                        </a>
                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="text-center py-5">
                                <p class="mt-3 mb-0">
                                    <i class="fa-regular fa-eye-slash"></i>
                                    Không tìm thấy phòng phù hợp.
                                </p>
                            </div>
                        <?php endif; ?>

                    </div>

                    
                    <div class="mt-4 d-flex justify-content-center"><?php echo e($phongs->links()); ?></div>
                </div>
            </div>
        </div>
    </section>

    
    <div id="compareBar" class="compare-bar" style="display: none;">
        <div class="container">
            <div class="d-flex justify-content-between align-items-center">
                <div class="d-flex align-items-center gap-3">
                    <i class="bi bi-check2-square fs-4"></i>
                    <div>
                        <h6 class="mb-0">So sánh phòng</h6>
                        <small class="text-muted"><span id="compareCount">0</span> phòng đã chọn (Tối đa 4)</small>
                    </div>
                </div>
                <div class="d-flex gap-2">
                    <button class="btn btn-outline-light btn-sm" id="clearCompare">
                        <i class="bi bi-trash me-1"></i> Xóa tất cả
                    </button>
                    <a href="<?php echo e(route('rooms.compare')); ?>" class="btn btn-light btn-sm">
                        <i class="bi bi-arrow-right-circle me-1"></i> So sánh ngay
                    </a>
                </div>
            </div>
        </div>
    </div>

    <?php $__env->startPush('scripts'); ?>
        <script src="https://cdn.jsdelivr.net/npm/nouislider@15.7.0/dist/nouislider.min.js"></script>
        <link href="https://cdn.jsdelivr.net/npm/nouislider@15.7.0/dist/nouislider.min.css" rel="stylesheet">

        <script>
            document.addEventListener('DOMContentLoaded', function() {
                var priceSlider = document.getElementById('price-slider');
                var minInput = document.getElementById('gia_min');
                var maxInput = document.getElementById('gia_max');
                var minLabel = document.getElementById('min-price');
                var maxLabel = document.getElementById('max-price');

                var minVal = parseInt(minInput.value);
                var maxVal = parseInt(maxInput.value);

                noUiSlider.create(priceSlider, {
                    start: [minVal, maxVal],
                    connect: true,
                    range: {
                        'min': <?php echo e($giaMin); ?>,
                        'max': <?php echo e($giaMax); ?>

                    },
                    step: 50000,
                    format: {
                        to: value => Math.round(value),
                        from: value => Math.round(value)
                    }
                });

                priceSlider.noUiSlider.on('update', function(values) {
                    minInput.value = values[0];
                    maxInput.value = values[1];
                    minLabel.textContent = new Intl.NumberFormat('vi-VN').format(values[0]) + 'đ';
                    maxLabel.textContent = new Intl.NumberFormat('vi-VN').format(values[1]) + 'đ';
                });
            });
        </script>

        
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                const MAX_COMPARE = 4;
                const STORAGE_KEY = 'compareRooms';

                // Get compared rooms from localStorage
                function getComparedRooms() {
                    const stored = localStorage.getItem(STORAGE_KEY);
                    return stored ? JSON.parse(stored) : [];
                }

                // Save compared rooms to localStorage
                function saveComparedRooms(rooms) {
                    localStorage.setItem(STORAGE_KEY, JSON.stringify(rooms));
                }

                // Update compare bar visibility and count
                function updateCompareBar() {
                    const rooms = getComparedRooms();
                    const compareBar = document.getElementById('compareBar');
                    const compareCount = document.getElementById('compareCount');
                    
                    if (rooms.length > 0) {
                        compareBar.style.display = 'block';
                        compareCount.textContent = rooms.length;
                    } else {
                        compareBar.style.display = 'none';
                    }

                    // Update all compare buttons state
                    document.querySelectorAll('.compare-btn').forEach(btn => {
                        const roomId = parseInt(btn.dataset.roomId);
                        const isCompared = rooms.some(r => r.id === roomId);
                        
                        if (isCompared) {
                            btn.classList.remove('btn-outline-primary');
                            btn.classList.add('btn-success');
                            btn.querySelector('.compare-text').textContent = 'Đã chọn';
                            btn.querySelector('i').classList.remove('bi-plus-circle');
                            btn.querySelector('i').classList.add('bi-check-circle-fill');
                        } else {
                            btn.classList.remove('btn-success');
                            btn.classList.add('btn-outline-primary');
                            btn.querySelector('.compare-text').textContent = 'So sánh';
                            btn.querySelector('i').classList.remove('bi-check-circle-fill');
                            btn.querySelector('i').classList.add('bi-plus-circle');
                        }
                    });
                }

                // Add/Remove room from compare
                document.querySelectorAll('.compare-btn').forEach(btn => {
                    btn.addEventListener('click', function() {
                        const roomId = parseInt(this.dataset.roomId);
                        let rooms = getComparedRooms();
                        
                        const existingIndex = rooms.findIndex(r => r.id === roomId);
                        
                        if (existingIndex !== -1) {
                            // Remove from compare
                            rooms.splice(existingIndex, 1);
                            saveComparedRooms(rooms);
                            updateCompareBar();
                        } else {
                            // Add to compare
                            if (rooms.length >= MAX_COMPARE) {
                                alert(`Bạn chỉ có thể so sánh tối đa ${MAX_COMPARE} phòng cùng lúc!`);
                                return;
                            }
                            
                            rooms.push({
                                id: roomId,
                                name: this.dataset.roomName,
                                price: parseFloat(this.dataset.roomPrice),
                                image: this.dataset.roomImage
                            });
                            
                            saveComparedRooms(rooms);
                            updateCompareBar();
                        }
                    });
                });

                // Clear all comparisons
                document.getElementById('clearCompare').addEventListener('click', function() {
                    if (confirm('Bạn có chắc muốn xóa tất cả phòng đã chọn?')) {
                        localStorage.removeItem(STORAGE_KEY);
                        updateCompareBar();
                    }
                });

                // Initial update
                updateCompareBar();
            });
        </script>
    <?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
    <style>
        /* Tùy chỉnh thanh trượt giá */
        .noUi-target,
        .noUi-target * {
            box-shadow: none !important;
        }

        .noUi-target {
            background: rgba(255, 255, 255, 0.3);
            border: 1px solid #ddd;
            border-radius: 10px;
            height: 8px;
        }

        .noUi-connect {
            background: rgba(110, 110, 110, 0.6) !important;
            transition: background 0.3s ease;
        }

        .noUi-handle {
            width: 26px !important;
            height: 26px !important;
            border-radius: 50% !important;
            background: #fff !important;
            border: 3px solid #5E3EFF !important;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
        }

        .noUi-handle:hover {
            border-color: #a58dff;
        }

        .sidebar-filter h6 {
            font-weight: 600;
            margin-bottom: 10px;
            color: #333;
        }

        .sidebar-filter .list-unstyled li {
            margin-bottom: 6px;
        }

        .filter-box {
            background: #fff;
            border-radius: 14px;
            padding: 20px;
            box-shadow: 0 4px 16px rgba(0, 0, 0, 0.05);
        }

        .filter-divider {
            border-top: 1px solid #eee;
            margin: 15px 0;
        }

        .filter-submit-btn {
            background: #6759ff;
            color: #fff;
            border: none;
            border-radius: 10px;
            width: 100%;
            padding: 10px 0;
            font-weight: 500;
            transition: 0.25s;
        }

        .filter-submit-btn:hover {
            background: #5845f5;
        }

        .object-fit-cover {
            object-fit: cover;
        }

        section.rounded-4 img {
            transition: transform 0.6s ease;
        }

        section.rounded-4:hover img {
            transform: scale(1.05);
        }

        /* Carousel ảnh phòng */
        .room-carousel-inner {
            height: 250px;
            overflow: hidden;
            border-radius: 14px 0 0 14px;
        }

        .room-carousel-img {
            height: 100%;
            width: 100%;
            object-fit: cover;
            transition: transform 0.6s ease;
        }

        .room-carousel-img:hover {
            transform: scale(1.05);
        }

        /* Đảm bảo toàn card không nhảy khi đổi ảnh */
        .room-card {
            min-height: 250px;
        }

        @media (max-width: 768px) {
            .room-carousel-inner {
                height: 200px;
            }
        }

        /* Compare Bar Styles */
        .compare-bar {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 1rem 0;
            box-shadow: 0 -4px 20px rgba(0, 0, 0, 0.15);
            z-index: 1000;
            animation: slideUp 0.3s ease-out;
        }

        @keyframes slideUp {
            from {
                transform: translateY(100%);
                opacity: 0;
            }
            to {
                transform: translateY(0);
                opacity: 1;
            }
        }

        .compare-bar h6 {
            margin: 0;
            font-weight: 600;
        }

        .compare-bar .btn-outline-light {
            border-color: rgba(255, 255, 255, 0.5);
            color: white;
        }

        .compare-bar .btn-outline-light:hover {
            background-color: rgba(255, 255, 255, 0.2);
            border-color: white;
        }

        .compare-bar .btn-light {
            background-color: white;
            color: #667eea;
            font-weight: 600;
        }

        .compare-bar .btn-light:hover {
            background-color: #f8f9fa;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }

        @media (max-width: 768px) {
            .compare-bar .d-flex {
                flex-direction: column;
                gap: 0.5rem;
            }
            
            .compare-bar .gap-2 {
                width: 100%;
            }
            
            .compare-bar .btn {
                width: 100%;
            }
        }
    </style>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\du_an_tot_nghiep\du_an_tot_nghiep\du_an_tot_nghiep\resources\views/list-room.blade.php ENDPATH**/ ?>