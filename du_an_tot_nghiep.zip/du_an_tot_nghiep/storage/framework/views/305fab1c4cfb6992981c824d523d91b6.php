<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Thêm Voucher</h1>
    <form action="<?php echo e(route('admin.voucher.store')); ?>" method="POST">
        <?php echo $__env->make('admin.voucher.form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <button type="submit" class="btn btn-success">Lưu</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\du_an_tot_nghiep\du_an_tot_nghiep\du_an_tot_nghiep\resources\views/admin/voucher/create.blade.php ENDPATH**/ ?>