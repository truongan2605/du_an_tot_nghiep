<?php $__env->startSection('title', 'Sửa loại giường'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Sửa loại giường</h2>

    <form action="<?php echo e(route('admin.bed-types.update', $bedType->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="mb-3">
            <label class="form-label">Tên</label>
            <input type="text" name="name" class="form-control" value="<?php echo e(old('name', $bedType->name)); ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Giới hạn người</label>
            <input type="number" name="capacity" class="form-control" min="1" value="<?php echo e(old('capacity', $bedType->capacity)); ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Giá (VND / đêm)</label>
            <input type="number" step="0.01" name="price" class="form-control" min="0" value="<?php echo e(old('price', $bedType->price)); ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Mô tả</label>
            <textarea name="description" class="form-control"><?php echo e(old('description', $bedType->description)); ?></textarea>
        </div>

        <button class="btn btn-primary" type="submit">Cập nhật</button>
        <a href="<?php echo e(route('admin.bed-types.index')); ?>" class="btn btn-secondary">Hủy</a>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\du_an_tot_nghiep\du_an_tot_nghiep\du_an_tot_nghiep\resources\views/admin/bed_types/edit.blade.php ENDPATH**/ ?>