<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h1 class="h4">Bài viết</h1>
            <div class="d-flex gap-2">
                <a href="<?php echo e(route('admin.blog.categories.index')); ?>" class="btn btn-outline-secondary">Danh mục</a>
                <a href="<?php echo e(route('admin.blog.tags.index')); ?>" class="btn btn-outline-secondary">Thẻ</a>
                <a href="<?php echo e(route('admin.blog.posts.trash')); ?>" class="btn btn-outline-secondary">Thùng rác</a>
                <a href="<?php echo e(route('admin.blog.posts.create')); ?>" class="btn btn-primary">+ Thêm bài</a>
            </div>
        </div>

        <form class="row g-2 mb-3">
            <div class="col-md-4"><input name="kw" value="<?php echo e(request('kw')); ?>" class="form-control"
                    placeholder="Tìm tiêu đề..."></div>
            <div class="col-md-3">
                <select name="status" class="form-select" onchange="this.form.submit()">
                    <option value="">-- Tất cả trạng thái --</option>
                    <option value="draft" <?php echo e(request('status') === 'draft' ? 'selected' : ''); ?>>Nháp</option>
                    <option value="published" <?php echo e(request('status') === 'published' ? 'selected' : ''); ?>>Đã xuất bản</option>
                </select>
            </div>
            <div class="col-md-2"><button class="btn btn-secondary w-100">Lọc</button></div>
        </form>

        <div class="card">
            <div class="table-responsive">
                <table class="table align-middle">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Tiêu đề</th>
                            <th>Danh mục</th>
                            <th>Trạng thái</th>
                            <th>Cập nhật</th>
                            <th class="text-end">Thao tác</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($posts->firstItem() + $i); ?></td>
                                <td><a href="<?php echo e(route('admin.blog.posts.edit', $p)); ?>"><?php echo e($p->title); ?></a></td>
                                <td><?php echo e($p->category?->name ?: '—'); ?></td>
                                <td><span
                                        class="badge <?php echo e($p->status === 'published' ? 'bg-success' : 'bg-secondary'); ?>"><?php echo e($p->status); ?></span>
                                </td>
                                <td><?php echo e($p->updated_at->format('d/m/Y H:i')); ?></td>
                                <td class="text-end">
                                    <form action="<?php echo e(route('admin.blog.posts.destroy', $p)); ?>" method="POST"
                                        onsubmit="return confirm('Chuyển vào thùng rác?')">
                                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                        <a class="btn btn-sm btn-outline-primary"
                                            href="<?php echo e(route('admin.blog.posts.edit', $p)); ?>">Sửa</a>
                                        <button class="btn btn-sm btn-outline-danger">Xóa</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <div class="card-footer"><?php echo e($posts->links()); ?></div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\du_an_tot_nghiep\du_an_tot_nghiep\du_an_tot_nghiep\resources\views/admin/blog/posts/index.blade.php ENDPATH**/ ?>