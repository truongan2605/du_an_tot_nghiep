<?php echo csrf_field(); ?>
<div class="mb-3">
    <label for="code">Tên voucher</label>
    <input type="text" name="name" class="form-control"
    value="<?php echo e(old('name', $voucher->name ?? '')); ?>" required>
</div>
<div class="mb-3">
    <label for="code">Mã voucher</label>
    <input type="text" name="code" class="form-control"
    value="<?php echo e(old('code', $voucher->code ?? '')); ?>" required>
</div>

<div class="mb-3">
    <label for="type">Loại</label>
    <select name="type" class="form-control" required>
        <option value="fixed" <?php echo e(old('type', $voucher->type ?? '') == 'fixed' ? 'selected' : ''); ?>>Giảm tiền</option>
        <option value="percent" <?php echo e(old('type', $voucher->type ?? '') == 'percent' ? 'selected' : ''); ?>>Giảm %</option>
    </select>
</div>

<div class="mb-3">
    <label for="value">Giá trị</label>
    <input type="number" step="0.01" name="value" class="form-control"
        value="<?php echo e(old('value', $voucher->value ?? '')); ?>" required>
</div>

<div class="mb-3">
    <label for="qty">Số lượng</label>
    <input type="number" name="qty" class="form-control"
    value="<?php echo e(old('qty', $voucher->qty ?? '')); ?>" required>
</div>

<div class="mb-3">
    <label for="usage_limit_per_user">Số lượt tối đa mỗi user</label>
    <input type="number" name="usage_limit_per_user" class="form-control"
        value="<?php echo e(old('usage_limit_per_user', $voucher->usage_limit_per_user ?? '')); ?>" required>
</div>

<div class="mb-3">
    <label for="start_date">Ngày bắt đầu</label>
    <input type="date" name="start_date" class="form-control"
        value="<?php echo e(old('start_date', $voucher->start_date ?? '')); ?>" required>
</div>

<div class="mb-3">
    <label for="end_date">Ngày kết thúc</label>
    <input type="date" name="end_date" class="form-control"
    value="<?php echo e(old('end_date', $voucher->end_date ?? '')); ?>"
    required>
</div>
<?php /**PATH C:\laragon\www\du_an_tot_nghiep\du_an_tot_nghiep\du_an_tot_nghiep\resources\views/admin/voucher/form.blade.php ENDPATH**/ ?>