<?php $__env->startSection('title', 'Chi tiết dịch vụ'); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2><i class="fas fa-eye me-2"></i>Chi tiết dịch vụ</h2>
        <div>
            <a href="<?php echo e(route('admin.tien-nghi.edit', $tienNghi)); ?>" class="btn btn-warning">
                <i class="fas fa-edit me-2"></i>Chỉnh sửa
            </a>
            <a href="<?php echo e(route('admin.tien-nghi.index')); ?>" class="btn btn-secondary">
                <i class="fas fa-arrow-left me-2"></i>Quay lại
            </a>
        </div>
    </div>

    <div class="row">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title mb-0">Thông tin dịch vụ</h5>
                </div>
                <div class="card-body">
                    <table class="table table-borderless">
                        <tr>
                            <td width="150"><strong>ID:</strong></td>
                            <td><?php echo e($tienNghi->id); ?></td>
                        </tr>
                        <tr>
                            <td><strong>Tên dịch vụ:</strong></td>
                            <td><?php echo e($tienNghi->ten); ?></td>
                        </tr>
                        <tr>
                            <td><strong>Mô tả:</strong></td>
                            <td><?php echo e($tienNghi->mo_ta ?: 'Không có mô tả'); ?></td>
                        </tr>
                        <tr>
                            <td><strong>Giá tiền:</strong></td>
                            <td><?php echo e(number_format($tienNghi->gia, 0, ',', '.')); ?> VND</td>
                        </tr>
                        <tr>
                            <td><strong>Trạng thái:</strong></td>
                            <td>
                                <span class="badge <?php echo e($tienNghi->active ? 'bg-success' : 'bg-secondary'); ?>">
                                    <?php echo e($tienNghi->active ? 'Hoạt động' : 'Không hoạt động'); ?>

                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td><strong>Ngày tạo:</strong></td>
                            <td><?php echo e($tienNghi->created_at->format('d/m/Y H:i:s')); ?></td>
                        </tr>
                        <tr>
                            <td><strong>Cập nhật lần cuối:</strong></td>
                            <td><?php echo e($tienNghi->updated_at->format('d/m/Y H:i:s')); ?></td>
                        </tr>
                    </table>
                </div>
            </div>

            <div class="card mt-4">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="card-title mb-0">Phòng có dịch vụ này</h5>
                    <span class="badge bg-primary"><?php echo e($rooms->total()); ?> phòng</span>
                </div>
                <div class="card-body">
                    <?php if($rooms->count() === 0): ?>
                        <div class="text-muted">Chưa có phòng nào được gán dịch vụ này.</div>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-hover align-middle">
                                <thead>
                                    <tr>
                                        <th>Mã phòng</th>
                                        <th>Loại phòng</th>
                                        <th>Tầng</th>
                                        <th>Sức chứa</th>
                                        <th>Số giường</th>
                                        <th>Giá mặc định</th>
                                        <th>Trạng thái</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $phong): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($phong->ma_phong); ?></td>
                                            <td><?php echo e($phong->loaiPhong?->ten); ?></td>
                                            <td><?php echo e($phong->tang?->ten); ?></td>
                                            <td><?php echo e($phong->suc_chua); ?></td>
                                            <td><?php echo e($phong->so_giuong); ?></td>
                                            <td><?php echo e(number_format($phong->gia_mac_dinh, 0, ',', '.')); ?> đ</td>
                                            <td>
                                                <span
                                                    class="badge <?php echo e($phong->trang_thai === 'trong' ? 'bg-success' : 'bg-secondary'); ?>">
                                                    <?php echo e(ucfirst($phong->trang_thai)); ?>

                                                </span>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>

                        <div class="mt-3">
                            <?php echo e($rooms->links()); ?>

                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title mb-0">Icon</h5>
                </div>
                <div class="card-body text-center">
                    <?php if($tienNghi->icon && Storage::disk('public')->exists($tienNghi->icon)): ?>
                        <img src="<?php echo e(Storage::url($tienNghi->icon)); ?>" alt="<?php echo e($tienNghi->ten); ?>"
                            class="img-fluid rounded" style="max-height: 300px;">
                    <?php else: ?>
                        <div class="text-muted py-5">
                            <i class="fas fa-image fa-3x mb-3"></i>
                            <p>Chưa có icon</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="card mt-3">
                <div class="card-header">
                    <h5 class="card-title mb-0">Thao tác</h5>
                </div>
                <div class="card-body">
                    <div class="d-grid gap-2">
                        <a href="<?php echo e(route('admin.tien-nghi.edit', $tienNghi)); ?>" class="btn btn-warning">
                            <i class="fas fa-edit me-2"></i>Chỉnh sửa
                        </a>

                        <form action="<?php echo e(route('admin.tien-nghi.toggle-active', $tienNghi)); ?>" method="POST"
                            class="d-grid">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PATCH'); ?>
                            <button type="submit" class="btn <?php echo e($tienNghi->active ? 'btn-secondary' : 'btn-success'); ?>">
                                <i class="fas <?php echo e($tienNghi->active ? 'fa-toggle-off' : 'fa-toggle-on'); ?> me-2"></i>
                                <?php echo e($tienNghi->active ? 'Vô hiệu hóa' : 'Kích hoạt'); ?>

                            </button>
                        </form>

                        <form action="<?php echo e(route('admin.tien-nghi.destroy', $tienNghi)); ?>" method="POST"
                            onsubmit="return confirm('Bạn có chắc chắn muốn xóa dịch vụ này?')">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger w-100">
                                <i class="fas fa-trash me-2"></i>Xóa
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\du_an_tot_nghiep\du_an_tot_nghiep\du_an_tot_nghiep\resources\views/admin/tien-nghi/show.blade.php ENDPATH**/ ?>