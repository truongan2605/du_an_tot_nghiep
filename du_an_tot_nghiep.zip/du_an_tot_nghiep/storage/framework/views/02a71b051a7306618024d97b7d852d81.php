<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Danh sách Voucher</h1>
    <a href="<?php echo e(route('admin.voucher.create')); ?>" class="btn btn-primary mb-3">+ Thêm voucher</a>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Tên</th>
                <th>Mã</th>
                <th>Loại</th>
                <th>Giá trị</th>
                <th>Số lượng</th>
                <th>Số lượng còn lại</th>
                <th>Lượt/Người</th>
                <th>Ngày bắt đầu</th>
                <th>Ngày kết thúc</th>
                <th>Hành động</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $vouchers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $voucher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($voucher->name); ?></td>
                <td><?php echo e($voucher->code); ?></td>
                <td><?php echo e($voucher->type); ?></td>
                <td><?php echo e($voucher->value); ?></td>
                <td><?php echo e($voucher->qty); ?></td>
                <td><?php echo e(max(0, $voucher->qty - ($voucher->users_count ?? 0))); ?></td>
                <td><?php echo e($voucher->usage_limit_per_user); ?></td>
                <td><?php echo e($voucher->start_date); ?></td>
                <td><?php echo e($voucher->end_date); ?></td>
                <td>
                    <a href="<?php echo e(route('admin.voucher.show', $voucher->id)); ?>" class="btn btn-info btn-sm">Xem</a>
                    <a href="<?php echo e(route('admin.voucher.edit', $voucher->id)); ?>" class="btn btn-warning btn-sm">Sửa</a>

                    <?php if($voucher->active): ?>
                        
                        <form action="<?php echo e(route('admin.voucher.destroy', $voucher->id)); ?>" method="POST" style="display:inline-block;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-danger btn-sm"
                                onclick="return confirm('Bạn có chắc muốn vô hiệu hóa voucher này?')">
                                Vô hiệu hóa
                            </button>
                        </form>
                    <?php else: ?>
                        
                        <button class="btn btn-secondary btn-sm" disabled>Đã vô hiệu hóa</button>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\du_an_tot_nghiep\du_an_tot_nghiep\du_an_tot_nghiep\resources\views/admin/voucher/index.blade.php ENDPATH**/ ?>