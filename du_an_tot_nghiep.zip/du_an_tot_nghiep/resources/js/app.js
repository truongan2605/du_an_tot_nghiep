import './bootstrap';

// Import notification manager
import './notification-manager.js';
