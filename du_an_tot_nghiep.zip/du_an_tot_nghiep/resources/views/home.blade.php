@extends('layouts.app')

@section('title', 'Home - Booking')

@section('content')

    <!-- =======================
            Main Banner START -->
    <section class="pt-3 pt-lg-5">
        <div class="container">
            <!-- Content and Image START -->
            <div class="row g-4 g-lg-5">
                <!-- Content -->
                <div class="col-lg-6 position-relative mb-4 mb-md-0">
                    <!-- Title -->
                    <h1 class="mb-4 mt-md-5 display-5">Tìm trải nghiệm
                        <span class="position-relative z-index-9">Tuyệt vời nhất.
                            <!-- SVG START -->
                            <span
                                class="position-absolute top-50 start-50 translate-middle z-index-n1 d-none d-md-block mt-4">
                                <svg width="390.5px" height="21.5px" viewBox="0 0 445.5 21.5">
                                    <path class="fill-primary opacity-7"
                                        d="M409.9,2.6c-9.7-0.6-19.5-1-29.2-1.5c-3.2-0.2-6.4-0.2-9.7-0.3c-7-0.2-14-0.4-20.9-0.5 c-3.9-0.1-7.8-0.2-11.7-0.3c-1.1,0-2.3,0-3.4,0c-2.5,0-5.1,0-7.6,0c-11.5,0-23,0-34.5,0c-2.7,0-5.5,0.1-8.2,0.1 c-6.8,0.1-13.6,0.2-20.3,0.3c-7.7,0.1-15.3,0.1-23,0.3c-12.4,0.3-24.8,0.6-37.1,0.9c-7.2,0.2-14.3,0.3-21.5,0.6 c-12.3,0.5-24.7,1-37,1.5c-6.7,0.3-13.5,0.5-20.2,0.9C112.7,5.3,99.9,6,87.1,6.7C80.3,7.1,73.5,7.4,66.7,8 C54,9.1,41.3,10.1,28.5,11.2c-2.7,0.2-5.5,0.5-8.2,0.7c-5.5,0.5-11,1.2-16.4,1.8c-0.3,0-0.7,0.1-1,0.1c-0.7,0.2-1.2,0.5-1.7,1 C0.4,15.6,0,16.6,0,17.6c0,1,0.4,2,1.1,2.7c0.7,0.7,1.8,1.2,2.7,1.1c6.6-0.7,13.2-1.5,19.8-2.1c6.1-0.5,12.3-1,18.4-1.6 c6.7-0.6,13.4-1.1,20.1-1.7c2.7-0.2,5.4-0.5,8.1-0.7c10.4-0.6,20.9-1.1,31.3-1.7c6.5-0.4,13-0.7,19.5-1.1c2.7-0.1,5.4-0.3,8.1-0.4 c10.3-0.4,20.7-0.8,31-1.2c6.3-0.2,12.5-0.5,18.8-0.7c2.1-0.1,4.2-0.2,6.3-0.2c11.2-0.3,22.3-0.5,33.5-0.8 c6.2-0.1,12.5-0.3,18.7-0.4c2.2-0.1,4.4-0.1,6.7-0.1c11.5-0.1,23-0.2,34.6-0.4c7.2-0.1,14.4-0.1,21.6-0.1c12.2,0,24.5,0.1,36.7,0.1 c2.4,0,4.8,0.1,7.2,0.2c6.8,0.2,13.5,0.4,20.3,0.6c5.1,0.2,10.1,0.3,15.2,0.4c3.6,0.1,7.2,0.4,10.8,0.6c10.6,0.6,21.1,1.2,31.7,1.8 c2.7,0.2,5.4,0.4,8,0.6c2.9,0.2,5.8,0.4,8.6,0.7c0.4,0.1,0.9,0.2,1.3,0.3c1.1,0.2,2.2,0.2,3.2-0.4c0.9-0.5,1.6-1.5,1.9-2.5 c0.6-2.2-0.7-4.5-2.9-5.2c-1.9-0.5-3.9-0.7-5.9-0.9c-1.4-0.1-2.7-0.3-4.1-0.4c-2.6-0.3-5.2-0.4-7.9-0.6 C419.7,3.1,414.8,2.9,409.9,2.6z" />
                                </svg>
                            </span>
                            <!-- SVG END -->
                        </span>
                    </h1>
                    <!-- Info -->
                    <p class="mb-4">Chúng tôi mang đến cho bạn không chỉ một lựa chọn lưu trú mà còn là một trải nghiệm
                        tận hưởng sự sang trọng trong tầm giá của bạn.</p>

                    <!-- Buttons -->
                    <div class="hstack gap-4 flex-wrap align-items-center">
                        <!-- Button -->
                        <a href="#" class="btn btn-primary-soft mb-0">Khám phá ngay</a>
                        <!-- Story button -->
                        <a data-glightbox="" data-gallery="office-tour" href="https://www.youtube.com/embed/tXHviS-4ygo"
                            class="d-block">
                            <!-- Avatar -->
                            <div class="avatar avatar-md z-index-1 position-relative me-2">
                                <img class="avatar-img rounded-circle"
                                    src="{{ asset('template/stackbros/assets/images/avatar/12.jpg') }}" alt="avatar">
                                <!-- Video button -->
                                <div
                                    class="btn btn-xs btn-round btn-white shadow-sm position-absolute top-50 start-50 translate-middle z-index-9 mb-0">
                                    <i class="fas fa-play"></i>
                                </div>
                            </div>
                            <div class="align-middle d-inline-block">
                                <h6 class="fw-normal small mb-0">Theo dõi câu chuyện của chúng tôi</h6>
                            </div>
                        </a>
                    </div>
                </div>

                <!-- Image -->
                <div class="col-lg-6 position-relative">

                    <img src="{{ asset('template/stackbros/assets/images/bg/06.jpg') }}" class="rounded" alt="">

                    <!-- Svg decoration -->
                    <figure class="position-absolute end-0 bottom-0">
                        <svg width="163px" height="163px" viewBox="0 0 163 163">
                            <!-- svg content -->
                        </svg>
                    </figure>

                    <!-- Support guid -->
                    <div class="position-absolute top-0 end-0 z-index-1 mt-n4">
                        <div class="bg-blur border border-light rounded-3 text-center shadow-lg p-3">
                            <!-- Title -->
                            <i class="bi bi-headset text-danger fs-3"></i>
                            <h5 class="text-dark mb-1">24 / 7</h5>
                            <h6 class="text-dark fw-light small mb-0">Hướng dẫn hỗ trợ</h6>
                        </div>
                    </div>

                    <!-- Round image group -->
                    <div
                        class="vstack gap-5 align-items-center position-absolute top-0 start-0 d-none d-md-flex mt-4 ms-n3">
                        <img class="icon-lg shadow-lg border border-3 border-white rounded-circle"
                            src="{{ asset('template/stackbros/assets/images/category/hotel/4by3/11.jpg') }}" alt="avatar">
                        <img class="icon-xl shadow-lg border border-3 border-white rounded-circle"
                            src="{{ asset('template/stackbros/assets/images/category/hotel/4by3/12.jpg') }}" alt="avatar">
                    </div>
                </div>
            </div>
            <!-- Content and Image END -->

            <!-- Search START -->
            <form action="{{ route('list-room.index') }}" method="GET"
                class="card home-search-card shadow rounded-4 position-relative p-4 p-lg-4">

                <div class="row gy-3 gx-4 align-items-end">
                    {{-- Loại phòng --}}
                    <div class="col-xl-3 col-md-6 d-flex align-items-center">
                        <div class="flex-grow-1">
                            <label class="form-label home-search-label mb-1">Loại phòng</label>
                            <select class="form-select form-control-lg rounded-3" name="loai_phong_id"
                                data-search-enabled="true">
                                <option value="">-- Tất cả loại phòng --</option>
                                @foreach ($loaiPhongs as $loaiPhong)
                                    <option value="{{ $loaiPhong->id }}"
                                        {{ request('loai_phong_id') == $loaiPhong->id ? 'selected' : '' }}>
                                        {{ $loaiPhong->ten_loai_phong ?? $loaiPhong->ten }}
                                    </option>
                                @endforeach
                            </select>
                        </div>
                    </div>

                    {{-- Nhận phòng - Trả phòng (UI + Hidden submit chuẩn) --}}
                    <div class="col-xl-3 col-md-6 d-flex align-items-center">
                        <div class="flex-grow-1">
                            <label class="form-label home-search-label mb-1">Nhận phòng - Trả phòng</label>

                            {{-- UI input (hiển thị) --}}
                            <input type="text" id="date_range_ui_home"
                                class="form-control form-control-lg rounded-3 flatpickr" data-mode="range"
                                placeholder="Chọn ngày" value="{{ request('date_range') }}">

                            {{-- Hidden input (submit lên server theo chuẩn Y-m-d to Y-m-d) --}}
                            <input type="hidden" name="date_range" id="date_range_home"
                                value="{{ request('date_range') }}">
                        </div>
                    </div>

                    {{-- KHÁCH – POPUP --}}
                    <div class="col-xl-3 col-md-6 position-relative">
                        <label class="form-label home-search-label mb-1 d-block">Khách</label>

                        {{-- Nút mở popup --}}
                        <div id="guestSelectorBtn" class="guest-selector-box">
                            <i class="bi bi-people me-2"></i>
                            <span id="guestSummary">
                                {{ request('adults', 1) }} Người lớn,
                                {{ request('children', 0) }} Trẻ em
                            </span>
                            <i class="bi bi-chevron-down ms-auto"></i>
                        </div>

                        {{-- POPUP --}}
                        <div id="guestPopup" class="guest-popup shadow">
                            <div class="guest-row">
                                <div class="guest-info">
                                    <i class="bi bi-person icon"></i>
                                    <div>
                                        <div class="fw-bold">Người lớn</div>
                                        <small class="text-muted">Từ 13 tuổi</small>
                                    </div>
                                </div>
                                <div class="guest-control">
                                    <button type="button" class="btn-minus" data-target="adults">−</button>
                                    <span id="adultsCount">{{ request('adults', 1) }}</span>
                                    <button type="button" class="btn-plus" data-target="adults">+</button>
                                </div>
                            </div>

                            <div class="guest-row">
                                <div class="guest-info">
                                    <i class="bi bi-emoji-smile icon"></i>
                                    <div>
                                        <div class="fw-bold">Trẻ em</div>
                                        <small class="text-muted">Dưới 13 tuổi</small>
                                    </div>
                                </div>
                                <div class="guest-control">
                                    <button type="button" class="btn-minus" data-target="children">−</button>
                                    <span id="childrenCount">{{ request('children', 0) }}</span>
                                    <button type="button" class="btn-plus" data-target="children">+</button>
                                </div>
                            </div>

                            <small class="text-muted d-block mt-2">Mỗi phòng tối đa 2 trẻ em.</small>

                            {{-- THÔNG BÁO INLINE (thay cho alert) --}}
                            <div id="guestPopupMsg" class="small text-danger mt-2" style="display:none;"></div>

                            <button type="button" id="guestPopupDone" class="btn btn-primary w-100 mt-3 rounded-pill">
                                Xong
                            </button>
                        </div>

                        {{-- Hidden fields --}}
                        <input type="hidden" name="adults" id="adultsInput" value="{{ request('adults', 1) }}">
                        <input type="hidden" name="children" id="childrenInput" value="{{ request('children', 0) }}">
                    </div>

                    {{-- Số phòng --}}
                    <div class="col-xl-3 col-md-6">
                        <label class="form-label home-search-label mb-1">Số phòng</label>
                        <input type="number" name="rooms_count" id="home_rooms_count"
                            class="form-control form-control-lg rounded-3" min="1"
                            value="{{ request('rooms_count', 1) }}">
                    </div>

                    {{-- Hàng dưới: Giá + nút tìm kiếm --}}
                    <div class="col-12">
                        <div class="row gy-3 gx-4 align-items-center mt-1">
                            {{-- Giá --}}
                            <div class="col-lg-10 d-flex align-items-center">
                                <div class="flex-grow-1">
                                    <label class="form-label home-search-label mb-1">Giá (VNĐ)</label>
                                    <div id="price-slider-home" class="my-2"></div>
                                    <div class="d-flex justify-content-between small text-muted mt-1">
                                        <span id="min-price-home">{{ number_format($giaMin, 0, ',', '.') }}đ</span>
                                        <span id="max-price-home">{{ number_format($giaMax, 0, ',', '.') }}đ</span>
                                    </div>
                                    <input type="hidden" id="gia_min_home" name="gia_min"
                                        value="{{ request('gia_min', $giaMin) }}">
                                    <input type="hidden" id="gia_max_home" name="gia_max"
                                        value="{{ request('gia_max', $giaMax) }}">
                                </div>
                            </div>

                            {{-- Nút search --}}
                            <div class="col-lg-2 d-flex justify-content-lg-end justify-content-center">
                                <button type="submit"
                                    class="btn btn-primary home-search-btn d-inline-flex align-items-center justify-content-center">
                                    <i class="bi bi-search fs-4"></i>
                                    <span class="d-none d-md-inline ms-2">Tìm phòng</span>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
            <!-- Search END -->
        </div>
    </section>
    <!-- =======================
            Main Banner END -->

    <!-- =======================
             Blog Best deal (slider) START -->
    <section class="pb-2 pb-lg-5">
        <div class="container">

            <div class="tiny-slider arrow-round arrow-blur arrow-hover">
                <div class="tiny-slider-inner" data-autoplay="true" data-arrow="true" data-edge="2" data-dots="false"
                    data-items-xl="3" data-items-lg="2" data-items-md="1">

                    @foreach ($blogPosts ?? collect() as $post)
                        <!-- Slider item -->
                        <div>
                            <div class="card border rounded-3 overflow-hidden">
                                <div class="row g-0 align-items-center">
                                    <!-- Image -->
                                    <div class="col-sm-6">
                                        <a href="{{ route('blog.show', $post->slug) }}">
                                            <img src="{{ $post->cover_image ? asset('storage/' . $post->cover_image) : asset('assets/images/blog/feature.jpg') }}"
                                                class="card-img rounded-0" alt="{{ $post->title }}">
                                        </a>
                                    </div>

                                    <!-- Title and content -->
                                    <div class="col-sm-6">
                                        <div class="card-body px-3">
                                            @if ($post->category)
                                                <a href="{{ route('blog.index', ['category' => $post->category->slug]) }}"
                                                    class="badge bg-primary mb-2 text-white">{{ $post->category->name }}</a>
                                            @endif

                                            <h6 class="card-title mb-1">
                                                <a href="{{ route('blog.show', $post->slug) }}" class="stretched-link">
                                                    {{ $post->title }}
                                                </a>
                                            </h6>

                                            <p class="mb-2 text-muted small">
                                                {{ \Illuminate\Support\Str::limit($post->excerpt, 80) }}
                                            </p>

                                            <small class="text-muted">
                                                <i class="bi bi-calendar2-plus me-1"></i>
                                                {{ optional($post->published_at)->format('M d, Y') }}
                                                &nbsp;•&nbsp; By {{ optional($post->author)->name ?? 'Admin' }}
                                            </small>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    @endforeach

                </div>
            </div>

        </div>
    </section>
    <!-- =======================
             Blog Best deal END -->


    <!-- =======================
            About START -->
    <section class="pb-0 pb-xl-5">
        <div class="container">
            <div class="row g-4 justify-content-between align-items-center">
                <!-- Left side START -->
                <div class="col-lg-5 position-relative">

                    <!-- Image -->
                    <img src="{{ asset('template/stackbros/assets/images/about/01.jpg') }}"
                        class="rounded-3 position-relative" alt="">

                    <!-- Client rating START -->
                    <div class="position-absolute bottom-0 start-0 z-index-1 mb-4 ms-5">
                        <div class="bg-body d-flex d-inline-block rounded-3 position-relative p-3">

                            <!-- Element -->
                            <img src="{{ asset('template/stackbros/assets/images/element/01.svg') }}"
                                class="position-absolute top-0 start-0 translate-middle w-40px" alt="">

                            <!-- Avatar group -->
                            <div class="me-4">
                                <h6 class="fw-light">Client</h6>
                                <!-- Avatar group -->
                                <ul class="avatar-group mb-0">
                                    <li class="avatar avatar-sm">
                                        <img class="avatar-img rounded-circle"
                                            src="{{ asset('template/stackbros/assets/images/avatar/01.jpg') }}"
                                            alt="avatar">
                                    </li>
                                    <li class="avatar avatar-sm">
                                        <img class="avatar-img rounded-circle"
                                            src="{{ asset('template/stackbros/assets/images/avatar/02.jpg') }}"
                                            alt="avatar">
                                    </li>
                                    <li class="avatar avatar-sm">
                                        <img class="avatar-img rounded-circle"
                                            src="{{ asset('template/stackbros/assets/images/avatar/03.jpg') }}"
                                            alt="avatar">
                                    </li>
                                    <li class="avatar avatar-sm">
                                        <img class="avatar-img rounded-circle"
                                            src="{{ asset('template/stackbros/assets/images/avatar/04.jpg') }}"
                                            alt="avatar">
                                    </li>
                                    <li class="avatar avatar-sm">
                                        <div class="avatar-img rounded-circle bg-primary">
                                            <span
                                                class="text-white position-absolute top-50 start-50 translate-middle small">1K+</span>
                                        </div>
                                    </li>
                                </ul>
                            </div>

                            <!-- Rating -->
                            <div>
                                <h6 class="fw-light mb-3">Rating</h6>
                                <h6 class="m-0">4.4<i class="fa-solid fa-star text-warning ms-1"></i></h6>
                            </div>
                        </div>
                    </div>
                    <!-- Client rating END -->
                </div>
                <!-- Left side END -->

                <!-- Right side START -->
                <div class="col-lg-6">
                    <h2 class="mb-3 mb-lg-5">Kỳ nghỉ tuyệt vời nhất bắt đầu từ đây!</h2>
                    <p class="mb-3 mb-lg-5">Đặt phòng khách sạn với chúng tôi và đừng quên nắm bắt ưu đãi khách sạn tuyệt
                        vời để tiết kiệm đáng kể cho kỳ nghỉ của bạn.</p>

                    <!-- Features START -->
                    <div class="row g-4">
                        <!-- Item -->
                        <div class="col-sm-6">
                            <div class="icon-lg bg-success bg-opacity-10 text-success rounded-circle"><i
                                    class="fa-solid fa-utensils"></i></div>
                            <h5 class="mt-2">Đồ ăn chất lượng</h5>
                            <p class="mb-0">Đảm bảo chất lượng đồ ăn đẳng cấp 5 sao từ những đầu bếp hàng đầu</p>
                        </div>
                        <!-- Item -->
                        <div class="col-sm-6">
                            <div class="icon-lg bg-danger bg-opacity-10 text-danger rounded-circle"><i
                                    class="bi bi-stopwatch-fill"></i></div>
                            <h5 class="mt-2">Phục vụ nhanh chóng</h5>
                            <p class="mb-0">Đảm bảo chất lượng phục vụ nhanh chóng 24/7</p>
                        </div>
                        <!-- Item -->
                        <div class="col-sm-6">
                            <div class="icon-lg bg-orange bg-opacity-10 text-orange rounded-circle"><i
                                    class="bi bi-shield-fill-check"></i></div>
                            <h5 class="mt-2">Bảo mật khách hàng</h5>
                            <p class="mb-0">Thông tin khách hàng được bảo mật tuyệt đối</p>
                        </div>
                        <!-- Item -->
                        <div class="col-sm-6">
                            <div class="icon-lg bg-info bg-opacity-10 text-info rounded-circle"><i
                                    class="bi bi-lightning-fill"></i></div>
                            <h5 class="mt-2">Bảo vệ 24/7</h5>
                            <p class="mb-0">Có lực lượng bảo vệ hoạt động 24/7 đảm bảo an toàn khách hàng</p>
                        </div>
                    </div>
                    <!-- Features END -->

                </div>
                <!-- Right side END -->
            </div>
        </div>
    </section>
    <!-- =======================
            About END -->

    <!-- =======================
            Featured Hotels START -->
    <section>
        <div class="container mt-5">
            <!-- Title -->
            <div class="row mb-4">
                <div class="col-12 text-center">
                    <h2 class="mb-0">Các phòng nổi bật</h2>
                </div>
            </div>

            <div class="row g-4">
                @forelse($phongs as $phong)
                    <div class="col-sm-6 col-xl-3">
                        <!-- Card START -->
                        <div class="card card-img-scale overflow-hidden bg-transparent">
                            <!-- Image and overlay -->
                            <div class="card-img-scale-wrapper rounded-3">
                                <!-- Image: dùng helper trong model -->
                                <img src="{{ $phong->firstImageUrl() }}" class="card-img" alt="hotel image">

                                <!-- Wishlist button -->
                                @php
                                    $isFav = in_array($phong->id, $favoriteIds ?? []);
                                @endphp
                                <button type="button" class="btn btn-sm btn-wishlist position-absolute top-0 end-0 m-2"
                                    data-phong-id="{{ $phong->id }}" aria-pressed="{{ $isFav ? 'true' : 'false' }}"
                                    aria-label="{{ $isFav ? 'Remove from wishlist' : 'Add to wishlist' }}"
                                    title="{{ $isFav ? 'Remove from wishlist' : 'Add to wishlist' }}">
                                    <i
                                        class="{{ $isFav ? 'fa-solid fa-heart text-danger' : 'fa-regular fa-heart text-white' }}">
                                    </i>
                                </button>

                                <!-- Badge: Hiển thị loại phòng -->
                                <div class="position-absolute bottom-0 start-0 p-3">
                                    <div class="badge text-bg-dark fs-6 rounded-pill stretched-link">
                                        <i class="bi bi-geo-alt me-2"></i>
                                        {{ $phong->loaiPhong->ten_loai ?? ($phong->loaiPhong->ten ?? '—') }}
                                    </div>
                                </div>
                            </div>

                            <!-- Card body -->
                            <div class="card-body px-2">
                                <h5 class="card-title">
                                    <a href="{{ route('rooms.show', $phong->id) }}"
                                        class="stretched-link text-decoration-none">
                                        {{ $phong->loaiPhong->ten_loai ?? ($phong->loaiPhong->ten ?? '—') }}
                                    </a>
                                </h5>

                                <!-- Price and rating -->
                                <div class="d-flex justify-content-between align-items-center">
                                    <h6 class="text-success mb-0">
                                        {{ number_format($phong->gia_cuoi_cung, 0, '.', ',') }} VND
                                    </h6>

                                    @php
                                        $avg =
                                            isset($phong->avg_rating) && $phong->avg_rating
                                                ? round((float) $phong->avg_rating, 1)
                                                : null;
                                        $count = isset($phong->rating_count) ? (int) $phong->rating_count : 0;
                                    @endphp

                                    <div class="d-flex align-items-center text-muted small"
                                        title="{{ $count }} đánh giá">
                                        @if ($avg)
                                            <span class="me-2 fw-semibold"
                                                aria-label="Đánh giá trung bình">{{ number_format($avg, 1, '.', '') }}</span>
                                            <span class="me-1" aria-hidden="true">
                                                <i class="fa-solid fa-star text-warning"></i>
                                            </span>
                                            {{-- <span class="ms-1">({{ $count }})</span> --}}
                                        @else
                                            <span class="text-muted">Chưa có đánh giá</span>
                                        @endif
                                    </div>
                                </div>

                            </div>
                        </div>
                        <!-- Card END -->
                    </div>
                @empty
                    <div class="col-12 text-center">There are no rooms available yet.</div>
                @endforelse
            </div>
        </div>
    </section>
    <!-- =======================
            Featured Hotels END -->

    <!-- =======================
            Client START -->
    <section class="py-0 py-md-5">
        <div class="container">
            <div class="row g-4 g-lg-7 justify-content-center align-items-center">
                <!-- Image -->
                <div class="col-5 col-sm-3 col-xl-2">
                    <img src="{{ asset('template/stackbros/assets/images/client/01.svg') }}" class="grayscale"
                        alt="">
                </div>
                <!-- Image -->
                <div class="col-5 col-sm-3 col-xl-2">
                    <img src="{{ asset('template/stackbros/assets/images/client/02.svg') }}" class="grayscale"
                        alt="">
                </div>
                <!-- Image -->
                <div class="col-5 col-sm-3 col-xl-2">
                    <img src="{{ asset('template/stackbros/assets/images/client/03.svg') }}" class="grayscale"
                        alt="">
                </div>
                <!-- Image -->
                <div class="col-5 col-sm-3 col-xl-2">
                    <img src="{{ asset('template/stackbros/assets/images/client/04.svg') }}" class="grayscale"
                        alt="">
                </div>
                <!-- Image -->
                <div class="col-5 col-sm-3 col-xl-2">
                    <img src="{{ asset('template/stackbros/assets/images/client/05.svg') }}" class="grayscale"
                        alt="">
                </div>
                <!-- Image -->
                <div class="col-5 col-sm-3 col-xl-2">
                    <img src="{{ asset('template/stackbros/assets/images/client/06.svg') }}" class="grayscale"
                        alt="">
                </div>
            </div>
        </div>
    </section>
    <!-- =======================
            Client END -->

    <!-- =======================
            Download app START -->
    <section class="bg-light">
        <div class="container">
            <div class="row g-4">

                <!-- Help -->
                <div class="col-md-6 col-xxl-4">
                    <div class="bg-body d-flex rounded-3 h-100 p-4">
                        <h3><i class="fa-solid fa-hand-holding-heart"></i></h3>
                        <div class="ms-3">
                            <h5>Hỗ trợ 24/7 </h5>
                            <p class="mb-0">Nếu chúng tôi không đáp ứng được kỳ vọng của bạn theo bất kỳ cách nào, hãy
                                cho chúng tôi biết</p>
                        </div>
                    </div>
                </div>

                <!-- Trust -->
                <div class="col-md-6 col-xxl-4">
                    <div class="bg-body d-flex rounded-3 h-100 p-4">
                        <h3><i class="fa-solid fa-hand-holding-usd"></i></h3>
                        <div class="ms-3">
                            <h5>Thanh toán minh bạch</h5>
                            <p class="mb-0">Tất cả các khoản hoàn tiền đều đi kèm với đảm bảo minh bạch</p>
                        </div>
                    </div>
                </div>

                <div class="col-md-6 col-xxl-4">
                    <div class="bg-body d-flex rounded-3 h-100 p-4">
                        <h3><i class="fa-solid fa-shield"></i></i></h3>
                        <div class="ms-3">
                            <h5>Chính sách bảo mật</h5>
                            <p class="mb-0">Chính sách bảo mật rõ ràng đảm bảo an toàn thông tin khách hàng</p>
                        </div>
                    </div>
                </div>

                <!-- Download app -->

            </div>
        </div>
    </section>
    <!-- =======================
            Download app END -->


    @push('scripts')
        <script src="https://cdn.jsdelivr.net/npm/nouislider@15.7.0/dist/nouislider.min.js"></script>
        <link href="https://cdn.jsdelivr.net/npm/nouislider@15.7.0/dist/nouislider.min.css" rel="stylesheet">

        <script>
            document.addEventListener('DOMContentLoaded', function() {

                // =========================
                // HOME - Date range (UI + hidden submit chuẩn)
                // Submit: YYYY-MM-DD to YYYY-MM-DD
                // UI: d M
                // =========================
                (function initHomeDateRange() {
                    const ui = document.getElementById('date_range_ui_home');
                    const hidden = document.getElementById('date_range_home');
                    if (!ui || !hidden || typeof flatpickr === 'undefined') return;

                    if (ui._flatpickr) ui._flatpickr.destroy();

                    const isYmd = (s) => /^\d{4}-\d{2}-\d{2}$/.test((s || '').trim());
                    const monthMap = {
                        jan: '01',
                        feb: '02',
                        mar: '03',
                        apr: '04',
                        may: '05',
                        jun: '06',
                        jul: '07',
                        aug: '08',
                        sep: '09',
                        oct: '10',
                        nov: '11',
                        dec: '12'
                    };

                    function pad2(n) {
                        n = String(n || '').trim();
                        return n.length === 1 ? ('0' + n) : n;
                    }

                    function parseDMonAnyYear(str) {
                        const s = (str || '').trim();
                        let m = s.match(/^(\d{1,2})\s+([A-Za-z]{3,})\s+(\d{4})$/);
                        if (m) {
                            const dd = pad2(m[1]);
                            const mon = monthMap[String(m[2]).slice(0, 3).toLowerCase()];
                            const yy = m[3];
                            if (mon) return `${yy}-${mon}-${dd}`;
                        }
                        m = s.match(/^(\d{1,2})\s+([A-Za-z]{3,})$/);
                        if (m) {
                            const dd = pad2(m[1]);
                            const mon = monthMap[String(m[2]).slice(0, 3).toLowerCase()];
                            const yy = String(new Date().getFullYear());
                            if (mon) return `${yy}-${mon}-${dd}`;
                        }
                        return null;
                    }

                    function normalizeRange(raw) {
                        const val = (raw || '').trim();
                        if (!val) return null;

                        const parts = val.split(' to ').map(x => x.trim()).filter(Boolean);
                        if (parts.length !== 2) return null;

                        if (isYmd(parts[0]) && isYmd(parts[1])) return [parts[0], parts[1]];

                        const a = parseDMonAnyYear(parts[0]);
                        const b = parseDMonAnyYear(parts[1]);
                        if (a && b) return [a, b];

                        return null;
                    }

                    // Ưu tiên hidden (server trả về) nếu có, nếu không lấy ui.value
                    const raw = (hidden.value || '').trim() || (ui.value || '').trim();
                    const normalized = normalizeRange(raw);

                    const fp = flatpickr(ui, {
                        mode: "range",
                        minDate: "today",
                        dateFormat: "Y-m-d", // chuẩn để dateStr là Y-m-d
                        defaultDate: normalized ? normalized : null,
                        onChange: function(selectedDates, dateStr) {
                            hidden.value = dateStr || '';
                        },
                        altInput: true,
                        altFormat: "d M",
                        altInputClass: ui.className,
                    });

                    if (normalized) {
                        hidden.value = normalized[0] + ' to ' + normalized[1];
                        fp.setDate(normalized, false);
                    } else {
                        // nếu format lạ -> clear hidden để tránh submit sai
                        hidden.value = '';
                    }
                })();

                // =========================
                // Price slider
                // =========================
                var priceSlider = document.getElementById('price-slider-home');
                var minInput = document.getElementById('gia_min_home');
                var maxInput = document.getElementById('gia_max_home');
                var minLabel = document.getElementById('min-price-home');
                var maxLabel = document.getElementById('max-price-home');

                if (priceSlider && minInput && maxInput && minLabel && maxLabel) {
                    var minVal = parseInt(minInput.value);
                    var maxVal = parseInt(maxInput.value);

                    noUiSlider.create(priceSlider, {
                        start: [minVal, maxVal],
                        connect: true,
                        range: {
                            'min': {{ $giaMin }},
                            'max': {{ $giaMax }}
                        },
                        step: 50000,
                        format: {
                            to: value => Math.round(value),
                            from: value => Math.round(value)
                        }
                    });

                    priceSlider.noUiSlider.on('update', function(values) {
                        minInput.value = values[0];
                        maxInput.value = values[1];
                        minLabel.textContent = new Intl.NumberFormat('vi-VN').format(values[0]) + 'đ';
                        maxLabel.textContent = new Intl.NumberFormat('vi-VN').format(values[1]) + 'đ';
                    });
                }

                // ========== Guest popup logic (HOME) ==========
                const popup = document.getElementById("guestPopup");
                const btn = document.getElementById("guestSelectorBtn");

                const adultsCountEl = document.getElementById("adultsCount");
                const childrenCountEl = document.getElementById("childrenCount");

                const inputAdults = document.getElementById("adultsInput");
                const inputChildren = document.getElementById("childrenInput");

                const roomsInput = document.getElementById("home_rooms_count");
                const summary = document.getElementById("guestSummary");

                const msgEl = document.getElementById("guestPopupMsg");

                function showGuestMsg(message) {
                    if (!msgEl) return;
                    msgEl.textContent = message;
                    msgEl.style.display = "block";
                }

                function clearGuestMsg() {
                    if (!msgEl) return;
                    msgEl.textContent = "";
                    msgEl.style.display = "none";
                }

                function getRoomsHome() {
                    return parseInt(roomsInput?.value || '1', 10) || 1;
                }

                function getMaxChildrenHome() {
                    return getRoomsHome() * 2;
                }

                function clampChildrenHome() {
                    if (!childrenCountEl) return;
                    let val = parseInt(childrenCountEl.textContent || '0', 10);
                    const maxChildren = getMaxChildrenHome();
                    if (val > maxChildren) {
                        childrenCountEl.textContent = maxChildren;
                    }
                    if (val <= maxChildren) clearGuestMsg();
                }

                if (roomsInput) {
                    roomsInput.addEventListener('change', clampChildrenHome);
                    roomsInput.addEventListener('input', clampChildrenHome);
                }

                if (popup && btn && adultsCountEl && childrenCountEl && inputAdults && inputChildren && summary) {
                    btn.addEventListener("click", () => {
                        popup.style.display = popup.style.display === "block" ? "none" : "block";
                        if (popup.style.display === "block") clearGuestMsg();
                    });

                    popup.querySelectorAll(".btn-plus").forEach(button => {
                        button.addEventListener("click", () => {
                            const target = button.dataset.target;

                            if (target === 'adults') {
                                let v = parseInt(adultsCountEl.textContent || '1', 10);
                                adultsCountEl.textContent = v + 1;
                                clearGuestMsg();
                            } else if (target === 'children') {
                                let v = parseInt(childrenCountEl.textContent || '0', 10);
                                const maxChildren = getMaxChildrenHome();

                                if (v >= maxChildren) {
                                    showGuestMsg(
                                        `Mỗi phòng tối đa 2 trẻ em. (${getRoomsHome()} phòng ⇒ tối đa ${maxChildren} trẻ em)`
                                        );
                                    return;
                                }

                                childrenCountEl.textContent = v + 1;
                                clearGuestMsg();
                            }
                        });
                    });

                    popup.querySelectorAll(".btn-minus").forEach(button => {
                        button.addEventListener("click", () => {
                            const target = button.dataset.target;

                            if (target === 'adults') {
                                let v = parseInt(adultsCountEl.textContent || '1', 10);
                                if (v > 1) v--;
                                adultsCountEl.textContent = v;
                                clearGuestMsg();
                            } else if (target === 'children') {
                                let v = parseInt(childrenCountEl.textContent || '0', 10);
                                if (v > 0) v--;
                                childrenCountEl.textContent = v;
                                clearGuestMsg();
                            }
                        });
                    });

                    document.getElementById("guestPopupDone").addEventListener("click", () => {
                        clampChildrenHome();

                        inputAdults.value = adultsCountEl.textContent;
                        inputChildren.value = childrenCountEl.textContent;

                        summary.textContent =
                            `${adultsCountEl.textContent} Người lớn, ${childrenCountEl.textContent} Trẻ em`;

                        clearGuestMsg();
                        popup.style.display = "none";
                    });

                    document.addEventListener("click", (e) => {
                        if (!popup.contains(e.target) && !btn.contains(e.target)) {
                            clearGuestMsg();
                            popup.style.display = "none";
                        }
                    });
                }
            });
        </script>
    @endpush


@endsection

@push('styles')
    <style>
        /* Nút mở popup */
        .guest-selector-box {
            display: flex;
            align-items: center;
            gap: 8px;
            border: 1px solid #dadce0;
            background: #fff;
            padding: 12px 16px;
            border-radius: 14px;
            cursor: pointer;
            user-select: none;
        }

        .guest-selector-box:hover {
            border-color: #5E3EFF;
        }

        /* Popup */
        .guest-popup {
            position: absolute;
            top: 110%;
            left: 0;
            width: 100%;
            background: white;
            border-radius: 16px;
            padding: 16px;
            display: none;
            z-index: 50;
        }

        .guest-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 12px 0;
            border-bottom: 1px solid #eee;
        }

        .guest-row:last-child {
            border-bottom: none;
        }

        .guest-info {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .guest-info .icon {
            font-size: 26px;
            color: #5E3EFF;
        }

        .guest-control {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .btn-minus,
        .btn-plus {
            width: 32px;
            height: 32px;
            background: #f2f2f2;
            border: none;
            border-radius: 50%;
            font-size: 20px;
            line-height: 0;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .btn-minus:hover,
        .btn-plus:hover {
            background: #e0e0e0;
        }

        /* SEARCH CARD */
        .home-search-card {
            max-width: 1120px;
            margin: -40px auto 0 auto;
            border-radius: 26px;
            padding-top: 1.75rem !important;
            padding-bottom: 1.75rem !important;
        }

        .home-search-label {
            font-weight: 600;
            color: #7a7a7a;
            font-size: 0.9rem;
        }

        .home-search-card .form-control,
        .home-search-card .form-select {
            border-radius: 14px;
            border-color: #e3e4ec;
            height: 48px;
        }

        .home-search-card .form-control:focus,
        .home-search-card .form-select:focus {
            box-shadow: 0 0 0 0.15rem rgba(94, 62, 255, 0.15);
            border-color: #5E3EFF;
        }

        .home-search-btn {
            width: 100%;
            max-width: 180px;
            height: 48px;
            border-radius: 999px;
            background: #5E3EFF;
            border: none;
            box-shadow: 0 10px 20px rgba(94, 62, 255, 0.25);
        }

        .home-search-btn:hover {
            background: #4a2de6;
            box-shadow: 0 12px 24px rgba(74, 45, 230, 0.35);
        }

        /* CARD IMAGE */
        .card-img-scale-wrapper {
            aspect-ratio: 3 / 4;
            overflow: hidden;
        }

        .card-img-scale-wrapper img.card-img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            object-position: center;
            display: block;
        }

        .btn-wishlist {
            width: 36px;
            height: 36px;
            border-radius: 50%;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            background: rgba(0, 0, 0, 0.35);
            border: none;
            z-index: 1200;
            pointer-events: auto;
            box-shadow: 0 3px 10px rgba(0, 0, 0, 0.15);
        }

        .btn-wishlist i {
            font-size: 14px;
            color: #fff;
        }

        .btn-wishlist i.text-danger {
            color: #dc3545 !important;
        }

        /* Thanh trượt giá trang chủ */
        .noUi-target {
            background: rgba(255, 255, 255, 0.3);
            border: 1px solid #ddd;
            border-radius: 10px;
            height: 8px;
        }

        .noUi-connect {
            background: rgba(110, 110, 110, 0.6) !important;
        }

        .noUi-handle {
            width: 26px !important;
            height: 26px !important;
            border-radius: 50% !important;
            background: #fff !important;
            border: 3px solid #5E3EFF !important;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
        }

        .noUi-horizontal .noUi-handle {
            top: -9px;
        }

        /* ========================
            Best deal (blog slider)
            ======================== */

        .tiny-slider .card {
            height: 180px;
            display: flex;
            align-items: stretch;
        }

        .tiny-slider .card .row {
            height: 100%;
        }

        .tiny-slider .card .col-sm-6:first-child {
            flex: 0 0 45%;
            max-width: 45%;
            height: 100%;
            overflow: hidden;
        }

        .tiny-slider .card .col-sm-6:first-child img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            display: block;
        }

        .tiny-slider .card .col-sm-6:last-child {
            flex: 0 0 55%;
            max-width: 55%;
            height: 100%;
            padding: 12px 14px;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }

        .tiny-slider .card-title a {
            font-weight: 600;
            font-size: 15px;
            line-height: 1.3;
            display: -webkit-box;
            -webkit-line-clamp: 1;
            -webkit-box-orient: vertical;
            overflow: hidden;
        }

        .tiny-slider .card p {
            font-size: 13px;
            color: #6c757d;
            margin-bottom: 6px;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            overflow: hidden;
        }

        .tiny-slider .card small {
            font-size: 12px;
            color: #999;
        }

        @media (max-width: 991.98px) {
            .home-search-card {
                margin-top: 1.5rem;
                padding: 1.25rem 1rem !important;
            }
        }
    </style>
@endpush
